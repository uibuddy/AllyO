kindly follow below steps to run this app:

1. Open current folder 'testSample-Shiv' in command propmt then run below commands

2. testSample-Shiv> install npm

3. testSample-Shiv> npm run start